-----write a procedure to access the students based on city

CREATE PROC usp_RetrieveStudByCity_172404
(
@city     VARCHAR(30)
)
AS
BEGIN
  IF(@city IS NULL OR @city=' ')
  

BEGIN
  PRINT 'City should be provided'
  END
ELSE
BEGIN
 SELECT Stud_Code,Stud_Name,Address
 FROM Student_Master
 WHERE Address=@city
END
END

SELECT * FROM syscomments WHERE text LIKE '%172404%'


----EXECUTING WITH RESULT SET-------

EXEC usp_RetrieveStudByCity_172404 'chennai' WITH RESULT SETS((SCode INT,SName varchar(20), City VARCHAR(20)))




EXEC usp_RetrieveStudByCity_172404 @city='chennai'
EXEC usp_RetrieveStudByCity_172404 NULL
EXEC usp_RetrieveStudByCity_172404 ''
---WRITE A STORE PROCEDURE TO DISPLAY COUNT OF STUDENTS FROM PARTICULAR DEPARTMENT----


CREATE PROC usp_StudCou_172404
(@Dcode  INT,
@Scount INT OUT
)
AS
BEGIN
iF(@Dcode IS NULL OR @Dcode<0)
BEGIN
  PRINT 'Department code should be provided'
END
ELSE
BEGIN
   IF EXISTS (SELECT Dept_Code FROM Department_master WHERE Dept_code=@Dcode)
   BEGIN
   SELECT @Scount=COUNT(Stud_Code)
   FROM Student_master
   WHERE Dept_Code=@Dcode
   END
   ELSE
   BEGIN
   PRINT 'Department code'+ str(@Dcode) +' does not exsists'
   END
END
END

---EXCEPTION RAISED IN STORED PROCEDURE-----

DECLARE @count  INT
EXEC usp_StudCou_172404 0,@count OUT
SELECT @Count

------USING HELP TEXT TO VIEW THE DEFINATION OF STORED PROCEDURE----
SELECT * FROM syscomments WHERE text LIKE '%172404%'

SELECT * FROM sysobjects


SELECT OBJECT_DEFINITION(OBJECT_ID('usp_RetrieveStudByCity_172404') )

EXEC sp_helptext  usp_RetrieveStudByCity_172404 




DECLARE @DCode  INT
DECLARE @DName VARCHAR(20)
DECLARE @ErrorNumber  INT

SET @DCode=10
SET @DName='maintainance'
INSERT INTO Department_Master(Dept_code,DepT_NAme) VALUES
(@DCode,@DName)
SET @ErrorNumber=@@ERROR
IF @ErrorNumber>0
BEGIN
   print 'ERROR OCCURED'
   PRINT @ErrorNumber
END
ELSE
BEGIN
PRINT 'RECORD ADDED SUCCESSFULLY'
END



DECLARE @DCode  INT
DECLARE @DName VARCHAR(20)
DECLARE @ErrorNumber  INT

SET @DCode=10
SET @DName='maintainance'
BEGIN TRY
INSERT INTO Department_Master(Dept_code,DepT_NAme) VALUES
(@DCode,@DName)
END TRY
BEGIN CATCH
PRINT 'Error occured'
print ERROR_Number()
PRINT Error_Message()
PRINT Error_sEVERITY()

END CATCH

------RAISE ERROR AND THROW-----
BEGIN TRY
   DECLARE @result  INT
   SET @result =1/0
END TRY
BEGIN CATCH
   DECLARE @errormessage  VARCHAR(200)
   DECLARE @severity      INT

   SET @errormessage=ERROR_MESSAGE()
   SET @severity    =ERROR_SEVERITY()

   RAISERROR( @errormessage, @severity,1)
END CATCH


-----THROW KEYWORD-----
BEGIN TRY
   DECLARE @result  INT
   SET @result =1/0
END TRY
BEGIN CATCH
  THROW
END CATCH


select * from sysmessages

-----------write a stored procedure to display the staff  of specific designation-------


CREATE PROC usp_StffDes_172404
(
@des_code  INT
)
AS
BEGIN
  IF(@des_code IS NULL OR @des_code<=0)
BEGIN
  RAISERROR('Designation code cannot be NULL or less than 0',1,1)
  RETURN -1
END
ELSE
BEGIN
  IF NOT EXISTS(SELECT Design_code
                   from desig_master
                    WHERE Design_code=@des_code)
BEGIN
   RAISERROR('DESIGNATION CODE DOES NOT EXSISTS',1,1)
END
SELECT staff_code,staff_name,des_code from staff_master
WHERE Des_code=@des_code
END
END



EXEC usp_StffDes_172404 -1
EXEC usp_StffDes_172404 10
EXEC usp_StffDes_172404 101
EXEC usp_StffDes_172404 102