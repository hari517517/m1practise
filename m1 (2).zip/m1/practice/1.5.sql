1)select Staff_Name, dep.Dept_Code, Dept_Name,
Salary from staff_master sm inner join department_master dep ON sm.dept_code=dep.dept_code and salary>20000

2)select Staff_Name, dep.Dept_Code, Dept_Name,
Salary from staff_master sm inner join department_master dep ON sm.dept_code=dep.dept_code and dep.dept_code=20


3)select book_name,count(BT.ISSUE_DATE) COUNT from book_master bm INNER JOIN book_transaction bt ON  bm.book_code=bt.book_code  GROUP BY BOOK_NAME
select * from book_transaction
4)SELECT emp.EmployeeID , emp.EmployeeName, mgr.EmpoyeeName
FROM Employee_172404 emp
INNER JOIN Employee mgr
ON emp.ManagerID = mgr.EmployeeID
SELECT * FROM Staff_Master
SELECT * FROM Student_Marks

5)SELECT STAFF_NAME,DATENAME(dw,Hiredate) as day from staff_master 
order by DATENAME(dw,Hiredate) 

6)SELECT STAFF_NAME,DEPT_CODE,DEPT_NAME,COUNT(BOOK_CODE) 


SELECT * FROM STAFF_MASTER


select * from Book_Transaction