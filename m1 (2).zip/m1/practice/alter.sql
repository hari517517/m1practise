create table employee_172404( Employee_Code int not null,Employee_Name varchar(40) not null,Employee_DOB DateTime not null,Employee_EmailID varchar(20))


sp_help employee_172404


alter table emp_172404 add dob date
select * from emp_172404

sp_help employee_172404

alter table employee_172404 alter column  employee_emailid varchar(40)


ALTER TABLE Emp_172404 DROP COLUMN DOJ

EXEC sp_help emp_172404