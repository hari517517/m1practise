--compute marks
CREATE TABLE Marks_172404(
Test1 INT,
Test2 INT,
Total AS (Test1+Test2),
 TestAvg AS ((Test1+Test2)/2)
);
INSERT INTO Marks_172404(Test1,Test2,Total,TestAvg) VALUES(10,20,30,40)
error:The column "TestAvg" cannot be modified because it is either a computed column or is the result of a UNION operator.


INSERT INTO Marks_172404(Test1,Test2) VALUES(10,20)
select * from Marks_172404
EXEC sp_help Marks_172404

INSERT INTO Marks_172404(Test1,Test2) VALUES(10)
error:There are more columns in the INSERT statement than values specified in the VALUES clause. The number of values in the VALUES clause must match the number of columns specified in the INSERT statement.


--Identity Column

CREATE TABLE Printer_172404(PrinterID INT IDENTITY(1000,3),
PrinterName VARCHAR(40))

INSERT INTO Printer_172404(PrinterName) values(('HP LASER'))

EXEC sp_help Printer
select * from Printer_172404

INSERT INTO Printer_172404(PrinterID,PrinterName) values(10, 'mysql')
ERROR:Cannot insert explicit value for identity column in table 'Printer_172404' when IDENTITY_INSERT is set to OFF.


EXEC sp_help Printer_172404

--UNIQUEIDENTIFIER COLUMN
CREATE TABLE Hardware_172404
(
HardwareID  UNIQUEIDENTIFIER,
HardwareName VARCHAR(20))

INSERT INTO

Hardware_172404(HardwareID, hardwarename) values(101,'printer')
error:Operand type clash: int is incompatible with uniqueidentifier


INSERT INTO
Hardware_172404(HardwareID, hardwarename) values(NEWID(),'MOUSE')

SELECT * FROM HARDWARE_172404
EXEC sp_help Hardware_172404


