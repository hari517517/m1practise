CREATE DEFAULT Email_Default_172404
AS 'hr@cg.com'


EXEC sp_bindefault Email_Default_172404,'Employee_172404.Employee_EmailID'

insert    into   eMPLOYEE_172404(Employee_code,Employee_Name,eMPLOYEE_DOB)VALUES(2001,'ROSY','1999-05-03')


---RULE--
CREATE  RULE   DOB_Rule_172404
AS @DOB>='1900-01-01' AND @DOB<'2019-01-01'

EXEC sp_bindrule DOB_Rule_172404, 'Employee_172404.Employee_DOB'
INSERT INTO Employee_172404(Employee_code,Employee_Name,Employee_DOB,Employee_EmailID)VALUES(2002,'Ann','2000-03-02','amm@cg.com')



select Staff_Code,Staff_Sal,Dept_Code from Staff_Master where Dept_Code=20 OR Dept_Code =30 OR DEPT_CODE= 40

select student_code,subject1,subject2,subject3, (subject3+subject2+subject3) as Total_marks from student_marks
select book_name  from book_master where book_name like'An%'

select Dept_code from student_master where student_dob=2019

select staff_name from staff_master where HireDate<'jan 2000'
select Staff_Code,Staff_name,Dept_Code,Hiredate ,DATEDIFF(YEAR,Hiredate, GETDATE()) AS No_Of_Years from Staff_Master


 Select  STUDENT_CODE FROM STUDENT_MARKS WHERE subject2 IS NULL

 SELECT * FROM STAFF_MAster
 select student_name,dept_code,Student_dob from student_master where Student_dob between 'january 1,1981' and 'march 31,1983' 
			