SELECT COUNT(Stud_code) StudentCount
FROM Student_Master

SELECT Dept_Code,COUNT(Stud_code) StudentCount
FROM Student_Master
GROUP BY Dept_Code

SELECT COUNT(Stud_code) StudentCount
FROM Student_Master
GROUP BY Dept_Code



SELECT COUNT(Staff_Name) count,Dept_Code 
from Staff_Master
GROUP BY Dept_Code


SELECT COUNT(Staff_Code) count,Dept_Code,sum(Salary) totalsalary,Avg(Salary) avgsalary
FROM Staff_Master GROUP BY Dept_Code
select* from staff_master
SELECT  COUNT(DEPT_CODE) COUNT,	Des_Code
from staff_master
group by dept_code,Des_Code



SELECT * FROM STUDENT_MASTER

SELECT COUNT(Stud_Code) COUNT,Address
FROM Student_Master
GROUP BY Address



SELECT COUNT(Stud_Code) count,Address FROM Student_Master

GROUP BY Address
HAVING count(Stud_Code)>1