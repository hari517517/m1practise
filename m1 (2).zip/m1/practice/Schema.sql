use Training_23Jan19_Pune


GO 
create schema mouni123
GO
create table mouni123.Pro(ProID INT,Name VARCHAR(20),Quantity INT)

select * from mouni123.Pro