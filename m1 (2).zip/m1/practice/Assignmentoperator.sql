SELECT Degree='BE',Rollno=Stud_Code FROM Student_Master

SELECT Stud_Code,Subject1,Subject2,Subject3,Total=(Subject1+Subject2+Subject3),Average=(Subject1+Subject2+Subject3)/3 FROM Student_Marks