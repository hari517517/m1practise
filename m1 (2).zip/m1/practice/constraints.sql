INSERT INTO Emp_172404(EmpID,EmpName,Email,phone,DOB) VALUES(1003,'alisa','alisa@cg.com',9123456789,'2004-02-01')


select * from emp_172404


ALTER TABLE Emp_172404
ADD CONSTRAINT DF_Phone_172404 DEFAULT '0000000000' for phone



---CHECK


DELETE  Emp_172404 WHERE EmpID=1002
ALTER TABLE Emp_172404
ADD CONSTRAINT ck_DOB_172404
CHECK(DOB>'1970-01-01' AND DOB<'2010-01-01')

---primary
ALTER TABLE Emp_172404
ALTER COLUMN EmpID INT NOT NULL

ALTER TABLE EMP_172404 ADD CONSTRAINT PK_Emp_172404
PRIMARY KEY NONCLUSTERED(EmpID)

--UNIQUE


ALTER TABLE Emp_172404
ADD CONSTRAINT UN_ UNIQUE NONCLUSTERED (Email)

--foreign key--


CREATE TABLE Category_172404
(
CatID INT CONSTRAINT pk_Category_172404 PRIMARY KEY,
CatName VARCHAR(20),
)


INSERT INTO Category_172404(CatID,CatName)VALUES(1,'Stationary'),(2,'Accessories'),(3,'toys'),(4,'giftnames')

CREATE TABLE Product_172404
(
ProdId   INT,
ProdName VARCHAR(20),
Quantity Int        CONSTRAINT ck_Qty_172404 check(Quantity>3),
Price    MONEY,
CategoryID INT CONSTRAINT Fk_Prod_Cat_172404 REFERENCES Category_172404(CatID)
)

INSERT   INTO Product_172404(prodid,prodname,quantity,price,categoryid)values(103,'Doll',5,250,3)


select * from Product_172404


---DISABLING CONSTRAINT
ALTER TABLE Product_172404
NOCHECK CONSTRAINT ck_qty_172404

INSERT   INTO Product_172404(prodid,prodname,quantity,price,categoryid)values(104,'TOY CAR',1,250,3)

