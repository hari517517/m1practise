----OPERETORS


SELECT * from Student_Marks
SELECT
      Stud_Code,Subject1,Subject2,Subject3,
	  (Subject1+Subject2+Subject3) AS Total_Marks
	  FROM Student_Marks
SELECT Subject1,Subject2,Subject3, ((Subject1+Subject2+Subject3)/3)*100 AS Total_Marks from Student_Marks

SELECT Staff_Name from Staff_Master where Des_Code=102 OR Dept_Code=20
SELECT Staff_Name from Staff_Master where Des_Code=102 AND Dept_Code=20
SELECT Stud_code,subject1 from student_marks where subject1 between 70 and 90
SELECT Stud_Name from Student_Master  where dept_code=10 or dept_code=20


SELECT Stud_Name,Stud_Code,Dept_Code Where Dept_cODE in(10,30,40)


SELECT Stud_Name from Student_Master where Stud_Name LIKE '___'
SELECT Stud_Name from Student_Master where Stud_Name LIKE 'A%'
SELECT Stud_Name from Student_Master where Stud_Name LIKE '__HUL'
SELECT Stud_Name from Student_Master where Stud_Name LIKE '%l'
SELECT Stud_Name from Student_Master where Stud_Name LIKE '%h%'
SELECT Stud_Name from Student_Master where Stud_Name NOT LIKE '%m%'


select * from staff_master