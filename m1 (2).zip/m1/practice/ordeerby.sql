-----------order by-----
select * from employee_172404


SELECT Employee_Code,Employee_Name from Employee_172404


SELECT ProdId,ProdName FROM  Product_172404 WHERE CategoryID=1



select * from product_172404

select * 
from Employee_172404
 ORDER BY Employee_Code DESC
 
 ----multiple column ordering----
 select * 
from Employee_172404
 ORDER BY Employee_Code DESC
 