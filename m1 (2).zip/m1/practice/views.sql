exec sp_helpindex Emp_172404

exec sp_help Emp_172404

----create view for storing data stud_code,stud_name, and dept_code

CREATE VIEW StudentView_172404
AS
SELECT stud_code,Stud_name,dept_code 
FROM Student_master


SELECT * from StudentView_172404

SELECT * from syscomments WHERE text LIKE '%172404%'

CREATE VIEW StuddepView_172404
AS
SELECT staff_code,staff_name,dept_name 
FROM Staff_Master stff INNER JOIN Department_master dm 
ON stff.dept_code=dm.dept_code



CREATE VIEW DepView_172404
WITH ENCRYPTION
AS
SELECT Dept_Code,COUNT(Stud_code) AS stud_count
FROM Student_master
GROUP BY Dept_code

select * from DepView_172404