----SYSTEM DEFINED OPERATORS----------


SELECT STR(23)
SELECT REPLACE('AAAAAA','A','X')
SELECT REPLACE(Stud_Name,'e','XX') FROM sTUDENT_mASTER

SELECT LEFT('Pearls are pretty',3)

SELECT LEFT(Stud_Name,3) FROM sTUDENT_mASTER

SELECT RIGHT('Pearls are pretty',3)

SELECT RIGHT(Stud_Name,3) FROM sTUDENT_mASTER
SELECT SUBSTRING('Pearls are pretty',4,3)

SELECT LEN('Pearls are pretty')
SELECT REVERSE('Pearls are pretty')
SELECT LOWER('Pearls are pretty')
SELECT UPPER('Pearls are pretty')

SELECT Stud_Name+'has student code'+STR(stud_code) from Student_Master


