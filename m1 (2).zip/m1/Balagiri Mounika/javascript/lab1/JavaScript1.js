JavaScript1.js
function sayHello() {
    document.write("<code>This text is displayed by calling an external function:</code> <strong>Hello World!</strong>");

}