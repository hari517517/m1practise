1)select Student_Code,Staff_Name,Dept_Code from Student_Master
2)select staff_code,staff_name,dept_code from staff_master
3)select Staff_Code,Staff_Sal,Dept_Code from Staff_Master where Dept_Code=20 OR Dept_Code =30 OR DEPT_CODE= 40

4)select student_code,subject1,subject2,subject3, (subject3+subject2+subject3) as Total_marks from student_marks
5)select book_name  from book_master where book_name like'An%'

6)select Dept_code from student_master where student_doJ=2019

7)select staff_name from staff_master where HireDate<'jan 2000'
8)select Staff_Code,Staff_name,Dept_Code,Hiredate ,DATEDIFF(YEAR,Hiredate, GETDATE()) AS No_Of_Years from Staff_Master


9) Select  STUDENT_CODE FROM STUDENT_MARKS WHERE subject2 IS NULL

 SELECT * FROM STAFF_MAster
 10)select student_name,dept_code,Student_dob from student_master where Student_dob between 'january 1,1981' and 'march 31,1983' 


11)SELECT Stud_name,Stud_dob FROM Student_Master WHERE DATENAME(WEEKDAY,Stud_dob) IN('Saturday','Sunday')

select * from Student_Master

Casestudy:

CREATE TABLE Products1_172404
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)
--Insert records into target table
INSERT INTO Products1_172404
VALUES
(1,'Tea', 10.00),
(2, 'Coffee', 20.00),
(3, 'Muffin', 30.00),
(4, 'Biscuit', 40.00)


CREATE TABLE UpdatedProducts_172404
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)
--Insert records into source table
INSERT INTO UpdatedProducts_172404
VALUES
(1, 'Tea', 10.00),
(2, 'Coffee', 25.00),
(3, 'Muffin', 35.00),
(5, 'Pizza', 60.00)



MERGE Products1_172404 AS TARGET
USING UpdatedProducts_172404 AS SOURCE
ON (TARGET.ProductID = SOURCE.ProductID)
--When records are matched, update
--the records if there is any change
WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.ProductName = SOURCE.ProductName,
TARGET.Rate = SOURCE.Rate

WHEN NOT MATCHED BY TARGET THEN
INSERT (ProductID, ProductName, Rate)
VALUES (SOURCE.ProductID, SOURCE.ProductName, SOURCE.Rate)

WHEN NOT MATCHED BY SOURCE THEN
DELETE

OUTPUT $action,
DELETED.ProductID AS TargetProductID,
DELETED.ProductName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.ProductID AS SourceProductID,
INSERTED.ProductName AS SourceProductName,
INSERTED.Rate AS SourceRate;
SELECT @@ROWCOUNT;
GO

CREATE TABLE Employee1_172404
(
Employee_Number INT NOT NULL PRIMARY
KEY,
Employee_Name VARCHAR(30) NULL,
Salary FLOAT NULL,
Department_Number INT NULL,
Region VARCHAR(30) NULL
)
INSERT INTO EMPLOYEE1_172404(EMPLOYEE_NUMBER,EMPLOYEE_NAME) VALUES(101,'MOUNI'),(102,'DEEPU')



SELECT Region, Department_Number, AVG (Salary)
Average_Salary
From Employee1_172404
Group BY GROUPING SETS
( (Region, Department_Number),
(Region),
(Department_Number)
)
SELECT Region, Department_Number, AVG (Salary) Average_Salary
From Employee1_172404
Group BY Region, Department_Number
UNION
SELECT Region, Department_Number, AVG (Salary) Average_Salary
From Employee1_172404
Group BY (Region)
UNION
SELECT Region, Department_Number, AVG (Salary) Average_Salary
From Employee1_172404
Group BY (Department_Number)