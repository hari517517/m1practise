31)1)create type region_172404 from char(15)
2)CREATE DEFAULT  City_Default1_172404
AS 'NA'

4)alter table Customers ADD  Custom_region region_172404
3)EXEC sp_bindefault Area_Default_172404,'Employee_172404.Employee_Area'
5)alter table Customers ADD Gender char(1)

6)ALTER TABLE Customers_172404
ADD
CONSTRAINT  alpha_check
CHECK
(
     Gender like '%[^FTM]%'
)
7)create table orders_172404(OrdersID INT IDENTITY(1000,1) NOT NULL,CustomerID INT NOT NULL,OrdersDate DATETIME,Order_state char(1),CONSTRAINT  two_letters  CHECK(
Order_state like '%[^PC]%'))
8) ALTER TABLE Customer_172404 ADD CONSTRAINT Fk_CustOrders FOREIGN KEY(iCustomerid) REFERENCES Customer_172404(iCustomerId)

ALTER TABLE Orders_172404 ADD CONSTRAINT Fk_CustOrders_172404 FOREIGN KEY(Customerid) REFERENCES Customer_172404(iCustomerId)



9)CREATE SEQUENCE Seq123 
  START WITH 1
  MINVALUE 20 
  MAXVALUE 100
  NO CACHE



 CREATE SEQUENCE IdSequence_172404 AS INT
START WITH  99999
INCREMENT BY 1;

INSERT INTO Employees (EmployeeId, Name)
VALUES (NEXT VALUE FOR IdSequence, 'Shashank');
INSERT INTO Contractors (ContractorId, Name)
VALUES (NEXT VALUE FOR IdSequence, 'Aditya');
SELECT * FROM Employees;
SELECT * FROM Contractors;

