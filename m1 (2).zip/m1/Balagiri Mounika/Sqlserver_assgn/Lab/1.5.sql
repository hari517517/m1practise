1)select Staff_Name, dep.Dept_Code, Dept_Name,
Salary from staff_master sm inner join department_master dep ON sm.dept_code=dep.dept_code and salary>20000

2)select Staff_Name, dep.Dept_Code, Dept_Name,
Salary from staff_master sm inner join department_master dep ON sm.dept_code=dep.dept_code and dep.dept_code=20


3)select book_name,count(BT.ISSUE_DATE) COUNT from book_master bm INNER JOIN book_transaction bt ON  bm.book_code=bt.book_code  GROUP BY BOOK_NAME
select * from book_transaction
4)SELECT emp.EmployeeID , emp.EmployeeName, mgr.EmpoyeeName
FROM Employee_172404 emp
INNER JOIN Employee mgr
ON emp.ManagerID = mgr.EmployeeID
SELECT * FROM Staff_Master
SELECT * FROM Student_Marks

5)SELECT STAFF_NAME,DATENAME(dw,Hiredate) as day from staff_master 
order by DATENAME(dw,Hiredate) 

 select * from Staff_master
 select * from Department_master

 select Staff_code,Staff_name,dept_name,hiredate,
 datename(WEEKDAY,hiredate) as Day from staff_master s 
 inner join Department_master d 
 on s.dept_code=d.dept_code 

  -- 6
 select * from Staff_Master

 select staff_code,staff_name,dept_code,Hiredate,
 datediff(yyyy,hiredate,getdate()) as numberofyears from staff_master
 
 ----7
select * from Staff_Master where hiredate < '2000-01-01'





---8

select * from student_marks
select stud_code,subject1 from student_marks 
where subject1=(select max(subject1) from student_marks)

---9
select b.stud_code,subject1,stud_name from student_marks a
 inner join student_master b on a.stud_code=b.stud_code
where subject1=(select max(subject1) from student_marks)

--10
select * from book_master
select * from Book_Transaction

select book_code,author,book_category from book_master
where not exists(select * from book_transaction
where book_master.book_code=book_transaction.book_code)

--11

select * from staff_master
select * from student_master
 select staff_code,staff_name,stud_code,stud_name,b.dept_code 
 from staff_master a inner join student_master b
 on a.dept_code=b.dept_code 
 where b.dept_code=20
 
--12 
 select * from student_master
 select * from student_marks

 select b.stud_code,stud_name,a.year from student_master a
 inner join student_marks b on a.stud_code=b.stud_code
 where a.year<>2018

--13
 select * from student_master
 select * from book_transaction

 select a.stud_code,a.stud_name,b.book_code 
 from student_master a right outer join Book_Transaction b
 on a.Stud_Code=b.stud_code

 ----14

select * from mouni_172404.customer
truncate table mouni_172404.customer



--15
update mouni_172404.customer set 
contactNumber=replace(contactnumber,5554729,3332345)
where customerid='ANATR'

--16
update mouni_172404.customer set 
address1=replace(address1,'23 Tsawessen Blvd','19/2 12th blockSpring fields')
update mouni_172404.customer set
address2=replace(address2,'Tsawessen canada','Ireland-UK')
where customerid='BOTTM'
update mouni_172404.customerset
region=replace(region,'BC','EU')
where customerid='BOTTM'

--17

insert into mouni_172404.orders(customerid,ordersdate,orderstate)
values ('AROUT','4-jul-96','P')

insert into mouni_172404.orderscustomerid,ordersdate,orderstate)
values ('ALFKI','4-jul-96','C')

insert into mouni_172477.orders(customerid,ordersdate,orderstate)
values ('BLONP','8-jul-96','P')

insert into mouni_172477.orders(customerid,ordersdate,orderstate)
values ('ANTON','8-jul-96','P')

insert into mouni_172477.orders(customerid,ordersdate,orderstate)
values ('ANTON','9-jul-96','P')

insert into mouni_172404.orders(customerid,ordersdate,orderstate)
values ('BOTTM','10-jul-96','P')


insert into mouni_172404.orders(customerid,ordersdate,orderstate)
values ('BONAP','11-jul-96','C')

insert into sivagopi_172404.orders(customerid,ordersdate,orderstate)
values ('ANATR','12-jul-96','P')

insert into sivagopi_172404.orders(customerid,ordersdate,orderstate)
values ('BLAUSS','15-jul-96','P')

insert into sivagopi_172404.orders(customerid,ordersdate,orderstate)
values ('HILAA','16-jul-96','C')


---18
 delete from mouni_172404.orders where ordersstate='C'
select* from mouni_172404.orders



---19

truncate table mouni_172404.orders

---20
update mouni_172404.orders set ordersstate='C' where ordersdate<'1996-07-15'
