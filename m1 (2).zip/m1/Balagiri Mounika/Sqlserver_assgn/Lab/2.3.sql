



create table countries(country_code int, country_name varchar(10));

exec sp_help 'countries'

create index countries_ms 
on countries(country_name) 
where country_name='India';

select a.name,b.name 
as objectname, a.is_unique, a.type_desc, a.filter_definitiona
from sys.indexes a inner join sys.objects b 
on (a.object_id = b.object_id)
where b.name ='countries'
